<?php
 echo cloudinary()->getImageTag($publicId ?? '')->scale($width ?? '', $height ?? '')->serialize();
?><?php /**PATH /home/mengseu/y3s2/wct/backend-reportWebsite/vendor/cloudinary-labs/cloudinary-laravel/resources/views/components/image.blade.php ENDPATH**/ ?>