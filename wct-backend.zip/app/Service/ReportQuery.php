<?php 

// app/Queries/ReportQuery.php

namespace App\Service;

use Illuminate\Http\Request;

class ReportQuery
{
    public function transform(Request $request)
    {
        // Your logic for transforming the request, if needed
        return $request;
    }
}
