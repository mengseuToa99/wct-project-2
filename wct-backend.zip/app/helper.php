<?php

define("ROLE_USER", "user");
define("ROLE_ADMIN", "admin");

?>